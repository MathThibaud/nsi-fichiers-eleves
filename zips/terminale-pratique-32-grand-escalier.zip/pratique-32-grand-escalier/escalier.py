def lire_escalier(nom):
    """Renvoie la liste des efforts des marches lus dans le fichier nom
    (un entier par ligne, de la marche du bas vers celle du haut)"""
    fichier = open(nom, "r", encoding="utf-8")
    couts = []
    for ligne in fichier:
        if ligne.strip() != "":
            couts.append(int(ligne))
    fichier.close()
    return couts


APPELS = [0]   # APPELS[0] compte les appels de effort_rec (question 2)


def effort_rec(couts, i):
    """Renvoie l'effort minimal pour arriver sur la marche i (effort de la
    marche i compris), en montant d'une ou de deux marches à la fois.
    Version récursive."""
    pass  # A COMPLETER


def effort_total_rec(couts):
    """Renvoie l'effort minimal pour atteindre le sommet, situé juste
    au-dessus de la dernière marche (escalier d'au moins 2 marches)"""
    n = len(couts)
    return min(effort_rec(couts, n - 1), effort_rec(couts, n - 2))


def effort_memo(couts, i, memo):
    """Même résultat que effort_rec(couts, i), mais chaque valeur calculée
    est mémorisée dans le dictionnaire memo (clé : i)"""
    pass  # A COMPLETER


def effort_total_memo(couts):
    """Effort minimal pour atteindre le sommet, avec mémoïsation"""
    n = len(couts)
    memo = {}
    return min(effort_memo(couts, n - 1, memo), effort_memo(couts, n - 2, memo))


def effort_tab(couts):
    """Renvoie l'effort minimal pour atteindre le sommet, sans récursivité,
    en remplissant un tableau du bas vers le haut de l'escalier"""
    pass  # A COMPLETER


def effort_glouton(couts):
    """Stratégie gloutonne : on commence par la moins pénible des deux
    premières marches, puis on pose toujours le pied sur la moins pénible
    des deux marches suivantes. Renvoie l'effort total obtenu."""
    n = len(couts)
    if couts[0] <= couts[1]:
        i = 0
    else:
        i = 1
    total = couts[i]
    while i < n - 2:
        if couts[i + 1] <= couts[i + 2]:
            i = i + 1
        else:
            i = i + 2
        total = total + couts[i]
    return total


#############################################################################
# Fonction nécessaire pour la question 2                                    #
#############################################################################


def compter_appels(n):
    """Renvoie le nombre d'appels de effort_rec nécessaires à la version
    récursive pour un escalier de n marches (effort_rec doit commencer par
    l'instruction APPELS[0] = APPELS[0] + 1, voir la question 2)"""
    APPELS[0] = 0
    couts = [1] * n
    effort_total_rec(couts)
    return APPELS[0]


def test_effort_rec():
    assert effort_rec([3, 2, 5], 0) == 3
    assert effort_rec([3, 2, 5], 2) == 7
    assert effort_total_rec([10, 15, 20]) == 15
    assert effort_total_rec([1, 100, 1, 1, 1, 100, 1, 1, 100, 1]) == 6


def test_effort_memo():
    assert effort_total_memo([10, 15, 20]) == 15
    assert effort_total_memo([1, 100, 1, 1, 1, 100, 1, 1, 100, 1]) == 6
    assert effort_total_memo([2, 1] * 50) == 50


def test_effort_tab():
    assert effort_tab([10, 15, 20]) == 15
    assert effort_tab([1, 100, 1, 1, 1, 100, 1, 1, 100, 1]) == 6
    assert effort_tab([5, 5]) == 5
    assert effort_tab([2, 1] * 50) == 50
