def recherche_sequentielle(tab, x):
    """Renvoie un indice où se trouve x dans le tableau tab, ou -1 si x n'est
    pas dans tab"""
    for i in range(len(tab)):
        if tab[i] == x:
            return i
    return -1


def recherche_dichotomique(tab, x):
    """tab est un tableau trié dans l'ordre croissant. Renvoie un indice où se
    trouve x dans tab, ou -1 si x n'est pas dans tab"""
    pass  # A COMPLETER


def comparaisons_sequentielle(tab, x):
    """Renvoie le nombre d'éléments de tab comparés à x par la recherche
    séquentielle"""
    nb = 0
    for i in range(len(tab)):
        nb = nb + 1
        if tab[i] == x:
            return nb
    return nb


def comparaisons_dichotomique(tab, x):
    """Renvoie le nombre d'éléments de tab comparés à x par la recherche
    dichotomique"""
    pass  # A COMPLETER


def premiere_occurrence(tab, x):
    """tab est un tableau trié dans l'ordre croissant, qui peut contenir des
    doublons. Renvoie le plus petit indice où se trouve x dans tab, ou -1 si x
    n'est pas dans tab"""
    debut = 0
    fin = len(tab)          # on cherche entre debut (inclus) et fin (exclu)
    while debut < fin:
        milieu = (debut + fin) // 2
        if tab[milieu] < x:
            debut = milieu + 1
        elif tab[milieu] > x:
            fin = milieu
        else:
            return milieu
    return -1


def recherche_rec(tab, x, debut, fin):
    """tab est un tableau trié dans l'ordre croissant. Renvoie un indice où se
    trouve x dans tab entre les indices debut et fin (inclus), ou -1 si x n'y
    est pas. Version récursive."""
    pass  # A COMPLETER


#############################################################################
# Fonction nécessaire pour la question 2                                    #
#############################################################################


def comparer(n):
    """Cherche une valeur absente dans le tableau trié des n premiers nombres
    pairs et affiche le nombre de comparaisons de chaque méthode"""
    tab = [i for i in range(0, 2 * n, 2)]
    print("n =", n)
    print("  séquentielle :", comparaisons_sequentielle(tab, 2 * n + 1))
    print("  dichotomique :", comparaisons_dichotomique(tab, 2 * n + 1))


def test_recherche():
    tab = [2, 3, 5, 7, 11, 13, 17, 19, 23]
    assert recherche_dichotomique(tab, 2) == 0
    assert recherche_dichotomique(tab, 13) == 5
    assert recherche_dichotomique(tab, 23) == 8
    assert recherche_dichotomique(tab, 4) == -1
    assert recherche_dichotomique([], 4) == -1


def test_comparaisons():
    assert comparaisons_dichotomique([10, 20, 30], 20) == 1
    assert comparaisons_dichotomique([i for i in range(1000)], -1) == 9


def test_premiere_occurrence():
    assert premiere_occurrence([1, 2, 2, 2, 3], 2) == 1
    assert premiere_occurrence([5, 5, 5, 5, 5, 5, 5], 5) == 0
    assert premiere_occurrence([1, 2, 3], 4) == -1


def test_recherche_rec():
    tab = [2, 3, 5, 7, 11, 13, 17, 19, 23]
    assert recherche_rec(tab, 13, 0, len(tab) - 1) == 5
    assert recherche_rec(tab, 4, 0, len(tab) - 1) == -1
