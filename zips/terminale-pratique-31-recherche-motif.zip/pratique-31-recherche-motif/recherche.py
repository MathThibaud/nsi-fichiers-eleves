def lire_fichier(nom):
    """Renvoie le contenu du fichier texte nom, sans le saut de ligne final"""
    fichier = open(nom, "r", encoding="utf-8")
    texte = fichier.read()
    fichier.close()
    return texte.strip()


def recherche_naive(motif, texte):
    """Renvoie la liste, dans l'ordre croissant, de toutes les positions de
    texte où commence une occurrence de motif (méthode naïve)"""
    pass  # A COMPLETER


def table_decalage(motif):
    """Renvoie le dictionnaire des décalages de Boyer-Moore-Horspool : chaque
    lettre du motif, sauf la dernière, est associée à sa distance à la fin du
    motif (en cas de lettre répétée, on garde la plus proche de la fin)"""
    pass  # A COMPLETER


def horspool(motif, texte):
    """Renvoie la liste, dans l'ordre croissant, de toutes les positions de
    texte où commence une occurrence de motif (algorithme de
    Boyer-Moore-Horspool)"""
    n = len(texte)
    m = len(motif)
    dec = table_decalage(motif)
    positions = []
    i = 0
    while i <= n - m:
        j = m - 1
        while j >= 0 and texte[i + j] == motif[j]:
            j = j - 1
        if j < 0:
            positions.append(i)
            i = i + m
        else:
            c = texte[i + m - 1]
            if c in dec:
                i = i + dec[c]
            else:
                i = i + m
    return positions


def comparaisons_naive(motif, texte):
    """Renvoie le nombre de comparaisons de caractères effectuées par la
    méthode naïve"""
    pass  # A COMPLETER (question 4)


def comparaisons_horspool(motif, texte):
    """Renvoie le nombre de comparaisons de caractères effectuées par
    l'algorithme de Boyer-Moore-Horspool"""
    pass  # A COMPLETER


#############################################################################
# Fonction nécessaire pour la question 4                                    #
#############################################################################


def comparer():
    """Compare le nombre de comparaisons des deux méthodes sur trois cas"""
    adn = lire_fichier("adn.txt")
    phrases = "UN PETIT CHAT GRIS DORT AU SOLEIL. " * 3000
    cas = [("GATTACA", adn),
           ("LE CHIEN NOIR", phrases),
           ("A" * 9 + "B", "A" * 100000)]
    for motif, texte in cas:
        print("motif de longueur", len(motif), "dans un texte de longueur", len(texte))
        print("  naïve    :", comparaisons_naive(motif, texte))
        print("  horspool :", comparaisons_horspool(motif, texte))


def test_recherche_naive():
    assert recherche_naive("ACG", "CAAGACG") == [4]
    assert recherche_naive("AA", "AAAA") == [0, 1, 2]
    assert recherche_naive("ABC", "AB") == []
    assert recherche_naive("ICI", "ICI ET LA, ICI") == [0, 11]


def test_table_decalage():
    assert table_decalage("MOTIF") == {"M": 4, "O": 3, "T": 2, "I": 1}
    assert table_decalage("GATTACA") == {"G": 6, "A": 2, "T": 3, "C": 1}
    assert table_decalage("A") == {}


def test_horspool():
    # on verifie d'abord la table : un decalage nul ferait boucler horspool
    assert table_decalage("ACGT") == {"A": 3, "C": 2, "G": 1}
    assert horspool("MOTIF", "UN TEXTE AVEC UN MOTIF ICI") == [17]
    assert horspool("ACGT", "GTACACGTAC") == [4]
    assert horspool("ABA", "ABABABA") == [0, 2, 4]
    assert horspool("AA", "AAAA") == [0, 1, 2]


def test_comparaisons():
    assert comparaisons_naive("MOTIF", "UN TEXTE AVEC UN MOTIF ICI") == 26
    assert comparaisons_naive("AB", "AAAA") == 6
    assert comparaisons_horspool("MOTIF", "UN TEXTE AVEC UN MOTIF ICI") == 9
    assert comparaisons_horspool("AB", "AAAA") == 3
